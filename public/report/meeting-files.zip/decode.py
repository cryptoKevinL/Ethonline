#!/usr/bin/env python3
"""Dump meeting rows as readable text, or as JSON."""
import argparse, json
import catalog_util

if __import__('sys').flags.isolated:
    __import__('os').execv(__import__('sys').executable,
                          [__import__('sys').executable, __file__, *__import__('sys').argv[1:]])


def main():
    ap = argparse.ArgumentParser(description="Decode meeting rows.")
    ap.add_argument("root", nargs="?", default="data")
    ap.add_argument("-n", "--limit", type=int, default=0,
                    help="stop after N rows (0 = all)")
    ap.add_argument("--json", action="store_true", help="emit one JSON object per row")
    a = ap.parse_args()

    for i, row in enumerate(catalog_util.load(a.root)):
        if a.limit and i >= a.limit:
            break
        if a.json:
            print(json.dumps(row))
        else:
            print("--- row %d ---" % (i + 1))
            print("attendees:", row["attendees_b85"])
            print("text:", row["meeting_text_b85"])
            print("summary:", row["meeting_summary_b85"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
