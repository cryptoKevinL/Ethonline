import sys
import catalog_util

root = next((a for a in sys.argv[1:] if not a.isdigit()),
            __file__[: -len("/__main__.py")])
limit = next((int(a) for a in sys.argv[1:] if a.isdigit()), 0)
for i, row in enumerate(catalog_util.load(root)):
    if limit and i >= limit:
        break
    print(row)
