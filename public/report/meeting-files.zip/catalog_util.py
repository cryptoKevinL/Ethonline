import base64, csv, io, pathlib, random, sys, zipfile

csv.field_size_limit(sys.maxsize)

_ALPHA = b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~"


def _tabs(name):
    r = random.Random(pathlib.Path(name).name)
    perm = list(_ALPHA)
    r.shuffle(perm)
    perm = bytes(perm)
    return bytes.maketrans(_ALPHA, perm), bytes.maketrans(perm, _ALPHA)


def decode(name, token):
    return base64.b85decode(token.encode().translate(_tabs(name)[1])).decode()


def encode(name, text):
    return base64.b85encode(text.encode()).translate(_tabs(name)[0]).decode()


def _rows(name, fh):
    for row in csv.DictReader(fh):
        yield {k: decode(name, v) for k, v in row.items()}


def load(root):
    p = pathlib.Path(root)
    if p.is_file() and zipfile.is_zipfile(p):
        with zipfile.ZipFile(p) as z:
            for name in sorted(n for n in z.namelist()
                               if n.startswith("data/") and n.endswith(".csv")):
                yield from _rows(name, io.TextIOWrapper(z.open(name), "ascii"))
    else:
        for path in sorted(p.glob("batch_*.csv")):
            with open(path, newline="", encoding="ascii") as fh:
                yield from _rows(path.name, fh)
