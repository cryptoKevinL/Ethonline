import base64, csv, pathlib

def load(root):
    for path in sorted(pathlib.Path(root).glob("batch_*.csv")):
        with open(path, newline="", encoding="ascii") as fh:
            for row in csv.DictReader(fh):
                yield {k: base64.b85decode(v).decode() for k, v in row.items()}
