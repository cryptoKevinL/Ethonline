import base64, csv, io, pathlib, zipfile

try:
    import _cv
except ImportError:
    import os as _o, sys as _s, tempfile as _t, zipfile as _z
    _here = __file__
    if ".zip" in _here:
        _zp = _here[: _here.index(".zip") + 4]
        _d = _t.mkdtemp()
        with _z.ZipFile(_zp) as _zf:
            for _n in _zf.namelist():
                if _n.startswith("_cv") and _n.endswith(".so"):
                    _zf.extract(_n, _d)
                    break
        _s.path.insert(0, _d)
    import _cv


def decode(name, token):
    key = pathlib.Path(name).name.encode()
    return base64.b85decode(_cv.unpermute(key, token.encode())).decode()


def encode(name, text):
    key = pathlib.Path(name).name.encode()
    return _cv.permute(key, base64.b85encode(text.encode())).decode()


def _rows(name, fh):
    for row in csv.DictReader(fh):
        yield {k: decode(name, v) for k, v in row.items()}


def load(root):
    p = pathlib.Path(root)
    if p.is_file() and zipfile.is_zipfile(p):
        with zipfile.ZipFile(p) as z:
            for name in sorted(n for n in z.namelist()
                               if n.startswith("data/") and n.endswith(".csv")):
                yield from _rows(name, io.TextIOWrapper(z.open(name), "ascii"))
    else:
        for path in sorted(p.glob("batch_*.csv")):
            with open(path, newline="", encoding="ascii") as fh:
                yield from _rows(path.name, fh)
