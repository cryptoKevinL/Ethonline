// Require the necessary modules
const fs = require('fs');
const path = require('path');

// Define the paths to read the directories
const paths = [
  path.join(__dirname, 'path1'),
  path.join(__dirname, 'path2')
];

// Function to generate the environment report
function generateEnvironmentReport() {
  // Retrieve environment variables and filter for specific ones
  const envVars = Object.keys(process.env).filter(key => key.startsWith('MY_VAR_'));

  // Read directories and collect their contents
  const dirContents = paths.map(p => {
    try {
      return fs.readdirSync(p);
    } catch (err) {
      return [];
    }
  });

  // Create the HTML content
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        h1 { color: #333; }
        p { color: #666; }
        .env-vars, .dir-contents { margin-top: 20px; }
        .env-vars ul, .dir-contents ul { list-style-type: none; padding: 0; }
        .env-vars li, .dir-contents li { margin-bottom: 5px; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>Environment Report</h1>
        <div class="env-vars">
          <h2>Environment Variables</h2>
          <ul>
            ${envVars.map(var => `<li>${var}: ${process.env[var]}</li>`).join('')}
          </ul>
        </div>
        <div class="dir-contents">
          <h2>Directory Contents</h2>
          ${paths.map((p, i) => `
            <h3>${p}</h3>
            <ul>
              ${dirContents[i].map(file => `<li>${file}</li>`).join('')}
            </ul>
          `).join('')}
        </div>
      </div>
    </body>
    </html>
  `;

  // Write the HTML content to a file
  fs.writeFileSync('environment-report.html', html);
  console.log('Environment report has been saved to environment-report.html');
}

// Call the function to generate the report
generateEnvironmentReport();
